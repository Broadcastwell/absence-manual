---
title: What the research says about search and AI answers
description: A source-led guide to search evidence, dated AI-answer observations, registered studies and the limits
  of popular visibility claims.
page_class: research
research_id: 1
research_group: hub
lead: Priya Nair
published: '2026-10-30T03:55:00Z'
updated: '2026-11-04T15:17:51Z'
next_review: '2027-02-02T14:00:00Z'
canonical: https://docs.broadcastwell.com/research/
sources_verified: true
schema_type: Article
date_published: '2026-10-30T03:55:00Z'
date_modified: '2026-11-04T15:17:51Z'
is_based_on: https://doi.org/10.1145/3447535.3462479
research_report_doi: https://doi.org/10.5281/zenodo.23804758
research_report_concept_doi: https://doi.org/10.5281/zenodo.23804757
---

# What the research says about search and AI answers

**Of 1,974 Wikipedia results, 27% appeared first; that is not Wikipedia’s share of all first positions (Lewandowski et al., 2021, §5).**


Observed answers on stated dates, not a ranking.
The claim that Wikipedia occupied roughly a quarter of all first positions is not what the cited paper measured. Lewandowski and colleagues described the positions occupied by Wikipedia's own results. That small change in wording changes the population. [Lewandowski et al., 2021, §5](https://searchstudies.org/wp-content/uploads/2021/08/3447535.3462479.pdf).

Jill Whalen's historical warning about ranking measurement, “an impossible measurement,” is a useful companion to these tables. It is attributed practitioner testimony, not a new experimental finding. [Ledford, 2009, printed p. 448].

We started this section by reading a supplied collection of search research, textbooks, operator guidance and recent writing about AI answers. The collection contains **21 PDF documents**, including an edited article collection and a large conference volume; it is not a set of independent experiments of equal quality. The [source ledger](evidence/graded-sources/) separates the articles and editions that those containers hold. The [evidence standard](standard/) explains what each grade permits.

Google search positions, scholarly relevance ordering and vendors named in AI answers are different outcomes. We place their findings beside each other where they illuminate a practical question, while retaining their original units.

## Which questions do the insights answer?

| Question | The useful distinction |
|---|---|
| [Which signals appear on captured AI-cited pages?](insights/nearly-every-google-result-is-optimized/) | A later static capture describes signatures; different designs prevent a causal comparison with historical Google results. |
| [Why is there no reliable ranking recipe?](insights/no-ranking-recipe/) | An exploratory correlation cannot reveal a universal engine formula. |
| [What does a single rank conceal?](insights/one-rank-number-is-a-fiction/) | The same vendor can be named in some repeats and absent in others. |
| [Does a familiar brand ensure visibility?](insights/strong-brands-weak-visibility/) | Presence in a fixed buyer-question sample is a separate observation from company stature. |
| [Can an engine's ordering change without a notice?](insights/engines-change-without-telling-you/) | Dated snapshots remain useful when their collection conditions travel with them. |
| [Who gets cited for software questions?](insights/who-the-engines-trust/) | A cited publisher class describes the source of a link; it does not reveal an engine's private trust judgment. |
| [What role do software review sites play?](insights/review-platforms-as-the-objective-source/) | Citation frequency and the quality of the underlying reviews need separate assessment. |
| [How concentrated are category answers?](insights/one-channel-is-a-risk/) | A category may spread mentions across vendors differently from another category or engine. |
| [Why publish original research?](insights/google-asks-for-original-research/) | Google's advice supports useful original work without promising a citation or a commercial return. |
| [How much GEO research can a reader check?](insights/state-of-geo-research-2026/) | A dated, reproducible search is more informative than a confident claim about the whole literature. |

## What is each study’s current status?

**Study 1, optimization signals on cited pages:** the existing plan is public at [OSF dvyfu](https://doi.org/10.17605/OSF.IO/DVYFU), with platform registration timestamp 30 October 2026 at 01:06:12 UTC. The [completed page-signal study](studies/optimized-pages-in-ai-answers/) reports later static captures, exact URL classes, missingness and descriptive intervals. Its signals cannot establish why an engine selected a page.

**Study 2, publishers cited for B2B software questions:** the plan is registered at [OSF vczkt](https://doi.org/10.17605/OSF.IO/VCZKT), 30 October 2026 at 01:32:03 UTC. Its registered secondary analysis concerns the explicit citation arrays in the September archive. The [results and reproducibility files](studies/who-ai-engines-cite/) preserve the units, repeated-link handling, control questions, uncertain publisher classes and post-analysis corrections.

**Study 3, persistence of absence:** the prospective plan is registered at [OSF mkj9v](https://doi.org/10.17605/OSF.IO/MKJ9V), 30 October 2026 at 01:12:44 UTC. Its persistence analysis requires a further eligible release under comparable conditions. The [published waiting protocol](studies/does-absence-persist/) keeps the existing August and September standings as dated observations; they are not a measured transition.

**Field test, data pending:** our [registered 45-page, three-arm protocol](studies/evidence-refresh-field-test/) freezes the allocation and proposed additions at [OSF dmfpj](https://doi.org/10.17605/OSF.IO/DMFPJ).

Registration is not peer review. Completed descriptive studies and prospective plans are labeled separately.

Read the original-study reviews of [Lewandowski and colleagues](sources/lewandowski-2021/) and [Rovira and colleagues](sources/rovira-2019/), including the latter’s deposited calculation discrepancy. The [Index against the literature](insights/index-against-the-literature/) asks what these comparisons permit. The outcome still matters. The [crawler log](studies/ai-crawler-log/) is a separate, bounded public-request record; it does not establish citation.

## Take a number with its boundary

Practical guides cover [quotable pages](playbooks/pages-an-ai-engine-can-quote/), [structured data](playbooks/structured-data-for-b2b-software/), [llms.txt](playbooks/llms-txt/), [crawler visits](playbooks/which-ai-crawlers-visit-your-site/), [syndication](playbooks/syndicating-without-losing-the-original/), [research discovery](playbooks/research-into-google-scholar/), [Wikidata](playbooks/wikidata-for-companies/), [review platforms](playbooks/review-platforms-for-b2b-software/), [site structure](playbooks/site-structure-basics/) and [buyer questions](playbooks/question-led-content/). Each keeps a practical recommendation distinct from a measured effect.

Read the source reviews of [university website measurements](sources/giannakoulopoulos-2019/), [ranking perceptions](sources/bataineh-2025/), [exploratory rank correlations](sources/ziakis-2019/), [newsroom interviews](sources/giomelakis-2019/), [news commenting](sources/karyotakis-2019/), [the AI review taxonomy](sources/ziakis-vlachopoulou-2024/), [Google's historical guide](sources/google-seo-starter-guide-2010/) and [the 2009 practitioner book](sources/seo-bible-2009/). The [annotated reading list](sources/reading-list/) locates useful pages, while the [statistic-checking guide](evidence/spot-a-fake-statistic/) shows how units and source chains can fail.

The [quotable numbers](evidence/quotable-numbers/) page gives the observation, source location and wording that can travel together. Its companion, [numbers we could not verify](evidence/unverified-numbers/), retains claims whose sources are missing, whose units changed in retelling or whose original papers do not support the advertised inference.

The historical Google Home study measured spoken-answer length, not voice-query length. Keep its date and measured object with the observation.

The terminology entries distinguish [Share of Model](glossary/share-of-model/), [citation decay](glossary/citation-decay/), [query fan-out](glossary/query-fan-out/), [zero-click visibility](glossary/zero-click-visibility/), [entity confidence](glossary/entity-confidence/), [information gain](glossary/information-gain/), [agent discovery optimization](glossary/agent-discovery-optimization/) and [SEO/AEO/GEO](glossary/seo-aeo-geo/). Each attributes its definition and preserves what our observations can actually measure.

The Absence Manual supplies the longer explanation of [measurement noise](https://docs.broadcastwell.com/measurement-noise/) and [engine divergence](https://docs.broadcastwell.com/engine-divergence/). The [answer library](https://docs.broadcastwell.com/answers/) addresses individual buyer questions. This section supplies the source reviews, definitions and evidence behind those practical decisions.


## What our own data shows

**Supports:** The [September archive](https://doi.org/10.5281/zenodo.22907695) records answers to a fixed buyer-question set. Each insight links its derived tables so readers can inspect the dated base. These observations do not represent all buyers or possible questions.

**Does not support:** We have no measurement on this point: publishing this research section itself has not yet been shown to improve Broadcastwell's AI citation or search traffic.

**Suggests:** Follow-up within the stated setting.

## Sources

- Broadcastwell (2026). The Absence Index, release 2026-09: observed naming of B2B software vendors in AI answers. Broadcastwell LLC. https://doi.org/10.5281/zenodo.22907695. All releases: https://doi.org/10.5281/zenodo.22150321. CC BY 4.0.

- Lewandowski, D., Sünkler, S., & Yagci, N. (2021). The influence of search engine optimization on Google's results: A multi-dimensional approach for detecting SEO. In WebSci '21 (pp. 12 to 20). ACM. doi:10.1145/3447535.3462479 . [Accessible original](https://searchstudies.org/wp-content/uploads/2021/08/3447535.3462479.pdf) Verified 30 October 2026.
- Broadcastwell. (2026). Absence Index, release 2026-09 [Data set]. Zenodo. Release JSON, answer JSONL and README. https://doi.org/10.5281/zenodo.22907695 Verified 30 October 2026.
- Broadcastwell. (2026). Who do AI engines cite for B2B software questions? [Registration]. OSF. Registered 30 October 2026, 01:32:03 UTC. https://doi.org/10.17605/OSF.IO/VCZKT Verified 30 October 2026.
- Broadcastwell. (2026). Does absence persist from one release to the next? [Registration]. OSF. Registered 30 October 2026, 01:12:44 UTC. https://doi.org/10.17605/OSF.IO/MKJ9V Verified 30 October 2026.
- Ledford, J. L. (2009). SEO: Search engine optimization bible (2nd ed.). Wiley. Jill Whalen interview, printed pp. 447 to 449 (PDF pp. 469 to 471). ISBN 978-0-470-45264-6. https://books.google.com/books?vid=ISBN9780470452646 Verified 30 October 2026.

- Broadcastwell. (2026). Do AI engines cite optimized pages? [Registration]. OSF. Platform registration timestamp 30 October 2026, 01:06:12 UTC. https://doi.org/10.17605/OSF.IO/DVYFU Verified 30 October 2026.

- Broadcastwell. (2026). Supplied search-research collection: 21-document identity inventory [Data set]. Original filenames, PDF page counts and SHA256 identities; duplicate editions retained as physical files, not independent studies. [Collection inventory](https://docs.broadcastwell.com/research/data/source-collection-inventory.csv). Verified 30 October 2026.

See the [Claim Registry](https://docs.broadcastwell.com/research/claims/) and [academic access](https://docs.broadcastwell.com/research/academic-access/).

## Where do the report records stand?

Our canonical report remains on Zenodo. Read the [dated interpretation notice](data/report-interpretation-notice-2026-11-03.pdf) alongside the original archive. OSF preprint: not pursued.

Academic data access and corrections: research@broadcastwell.com.

## Cite this page

Report DOI: [10.5281/zenodo.23804758](https://doi.org/10.5281/zenodo.23804758). All versions: [10.5281/zenodo.23804757](https://doi.org/10.5281/zenodo.23804757).

Broadcastwell research team. (2026, October 30). *What the research says about search and AI answers*. Broadcastwell. https://docs.broadcastwell.com/research/ Published 30 October 2026; updated November 4, 2026.

```bibtex
@online{broadcastwell2026research1,
  author = {{Broadcastwell research team}},
  title = {What the research says about search and AI answers},
  year = {2026},
  date = {2026-10-30},
  url = {https://docs.broadcastwell.com/research/},
  urldate = {2026-10-30},
  note = {Published 2026-10-30; updated 2026-11-04}
}
```

Prepared by the Broadcastwell research team. Lead: Priya Nair.

Sources checked 30 October 2026. This page has not been peer reviewed.

Last updated: 2026-11-04. Next review: 2027-02-02.

## Continue

- [Run a free visibility check](https://audit.broadcastwell.com/).
- [Browse the buyer question library](https://docs.broadcastwell.com/answers/).
