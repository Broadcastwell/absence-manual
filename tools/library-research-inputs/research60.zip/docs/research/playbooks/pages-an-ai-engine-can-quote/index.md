---
title: How do you write a page an AI engine can quote?
description: Put a supported answer first, preserve the units behind each statistic, and make evidence easy to inspect
  without promising an AI citation.
page_class: research
research_id: 25
research_group: playbook
lead: Vikram Patel
published: '2026-10-30T03:55:00Z'
updated: '2026-11-04T15:17:51Z'
next_review: '2027-02-02T14:00:00Z'
canonical: https://docs.broadcastwell.com/research/playbooks/pages-an-ai-engine-can-quote/
sources_verified: true
schema_type: TechArticle
date_published: '2026-10-30T03:55:00Z'
date_modified: '2026-11-04T15:17:51Z'
is_based_on: https://arxiv.org/html/2311.09735v3
---

# How do you write a page an AI engine can quote?

**Write a supported answer whose evidence, date and counted unit remain clear when the passage is read alone.**


Observed answers on stated dates, not a ranking.
Aggarwal and colleagues tested statistics, quotations and source citations in an experimental answer system using position-adjusted word-count visibility and subjective impressions. Those measures are not the probability that an AI engine will cite a newly published B2B page. [Aggarwal et al., 2024, Table 1 and §4](https://arxiv.org/html/2311.09735v3).

The paper’s main result and five-seed appendix do not report the same estimates. We treat that headline as fragile rather than adopting it as a publishing effect. The paper also examines a deployed system, where results vary by method. Neither setting establishes a universal performance promise for a B2B page.

GEO experiment: Aggarwal et al. (KDD 2024) headline a gain of up to 40% in a position-adjusted word-count visibility metric. Treat it as fragile: the ICLR 2024 draft reported 37%, the paper's own five-seed rerun (appendix Table 6) gives 36.9%, and on Perplexity adding citations cut the judged score by 23% (19.0 vs 24.7) while keyword stuffing raised it 14%. It is not a citation, traffic or conversion gain.

We have not recovered the exact ICLR submission for an independent check of the reported 37% headline. That version comparison remains a reported historical claim, not a newly verified result. The KDD paper uses a 1,000-query supplied-source test split and a separate 200-example Perplexity experiment. These are metric comparisons, not count-based citation probabilities.

The steps below are our editorial recommendations. They help a person check and quote a page. Their specific order, sentence length and layout have not been established as an optimal formula by that paper.

## Put the supported answer before the sales introduction

Begin with the question the page can actually answer. If the evidence only describes a captured sample, say so in the opening. A short result-first sentence gives readers something definite to assess; a broad claim about transforming an industry gives them much less.

For this section we use a quotable sentence of fewer than 30 words near the top. That is an editorial constraint, not a discovered engine threshold. Keep the source beside the sentence. If the source qualification will not fit, narrow the statement rather than removing the qualification.

Compare these fictional examples:

| Draft wording | What a reader needs |
|---|---|
| “Meridian Ledger is the market leader.” | A defined market, a dated measure and a primary basis for leadership. Without those, replace the claim. |
| “Meridian Ledger supports invoice export.” | A link to current product documentation, the export formats and any plan or configuration limits. |
| “Our test proves buyers prefer Meridian Ledger.” | Who the buyers were, how preference was measured, the comparison and the uncertainty. If the test measured mentions, say mentions. |

Meridian Ledger is an invented product. The examples show wording decisions; they report no product capabilities or observed experiment.

## Keep a number attached to what it measures

A useful statistical sentence names the outcome, population or archive, date, numerator and eligible base. Where observations are dependent, explain that dependence near the uncertainty estimate. A percentage alone is easy to quote and easy to misuse.

Do not turn a count of citations into a share of buyers. A linked URL, a publisher host, a vendor name and a vendor-answer pair are different units. Repeated appearances can matter, but a repeated-link count answers a different question from a distinct-host count. Choose the unit that matches the decision and label it consistently in the sentence, table and download.

If the primary source gives only a rounded percentage, do not invent an exact numerator by multiplying it by a sample size. Report what the paper actually supplies. If you recalculate a quantity from deposited data, show that it is your calculation and provide the inputs and formula.

The [quotable-number table](https://docs.broadcastwell.com/research/evidence/quotable-numbers/) illustrates this discipline. A limitation beside a result is part of the result a reader needs to carry forward.

## Make quotations recoverable

Name the speaker or author, identify the work and give the relevant page or section. Quote only the wording needed for the point. Ellipses should not hide a reversal, uncertainty or condition. A historical interview can explain how a practitioner thought; it cannot, by itself, prove how a current answer engine works.

An attributed quotation also needs an interpretable noun. “Visibility” may mean word-count share in an experimental answer, a captured mention rate, a search impression or a human visit. Preserve the source’s meaning before borrowing the term for a new context.

For numerical claims, link directly to the study, operator documentation or deposited data. A convenient summary can help a reader navigate, but the summary should not silently replace the original evidence. Where access is restricted, provide an authorized accessible original when one exists and keep the source identity intact.

## Write a section that survives being read alone

Use headings that state the reader’s question or the section’s plain claim. Define an abbreviation when its meaning matters. Give the object a clear name instead of repeatedly referring to “this,” especially when a table could be separated from the preceding paragraph.

Put a caption under a figure that explains the denominator, date and exclusions. A comparison should say whether the same questions, engines and configuration were used. If they differ, make those differences visible before discussing the resulting percentages.

This does not require repeating the whole method under every chart. It requires enough context that a chart does not become a different claim when shown in a slide. Provide the fuller method and data through stable links for anyone who needs to investigate.

## Expose the evidence in ordinary page text

Keep the main answer, table labels, source list and date visible without requiring a visitor to open an account. Use text navigation and descriptive links so that a reader can move from the assertion to its evidence. Check the page on a phone as well as a larger screen; a denominator hidden beyond an unmarked horizontal edge is easy to miss.

Use structured data to describe the visible content accurately. It cannot rescue a missing argument or supply a real-world result that the page does not establish. Google says the fundamentals of SEO remain relevant for its AI features and that no special additional optimization is necessary. That guidance concerns Google’s features, not every AI service. [Google Search Central, AI features and your website](https://developers.google.com/search/docs/appearance/ai-features).

Before release, read the title, opening sentence and figure caption consecutively. Repair mismatched wording. Then follow the source links and check that each lands on the intended original.

## Date the evidence and define the next check

Show when the page was updated and when its sources were checked. A changed footer date is not evidence that a statistic was reverified. Maintain a correction note when a substantive result changes, retaining enough information for earlier readers to understand the difference.

Choose a next review based on what can change. A product capability may need checking after a release; a historical study’s published result is more stable, although a correction or a deposited calculation discrepancy can still matter. Do not let a current access date make an old observation sound newly measured.

Finally, keep the outcome claim modest. A well-supported page is easier for people to inspect and reuse. Whether a particular engine retrieves it, cites it or changes an answer remains an observation to measure later. Publishing the page does not complete that measurement.

Google Search Central states, “There are no additional technical requirements.” That sentence concerns eligibility for supporting links in Google AI features; it does not guarantee crawling, indexing or selection. [Google Search Central, AI features and your website, “Technical requirements for appearing in AI features”; verified 30 October 2026].

## What our own data shows

**Does not support:** We have no measurement on this point: the causal effect of this page format on citations or sales. Study 1 registers a descriptive test of observable signals on pages cited in the September Index. Its public plan distinguishes strong signals, weak signals, missing metadata and fetch failures. Those classes do not measure the causal benefit of rewriting a sentence.

**Supports:** We have no controlled measurement showing that this page format increases citations or sales. The released Index supplies dated naming and citation observations, which are a different outcome from an intervention effect.

A worked example from our [published citation study](/research/studies/who-ai-engines-cite/) is: 39 of 2,095 eligible target answers captured on 22 and 23 September 2026 had empty supplied citation lists, 1.9%, with a descriptive 95% Wilson interval of 1.4% to 2.5%. The [answer-base table](/research/data/answer-citation-bases.csv) makes the unit and denominator recoverable. This sentence illustrates how to report our own count; it does not show that this writing format earns a citation, or that those answers used no underlying sources.

**Suggests:** Follow-up within the stated setting.

## Sources

- Aggarwal, P., Murahari, V., Rajpurohit, T., Kalyan, A., Narasimhan, K., & Deshpande, A. (2024). GEO: Generative engine optimization. KDD 2024. https://doi.org/10.1145/3637528.3671900 . Author manuscript v3: https://arxiv.org/html/2311.09735v3 Verified 30 October 2026.
- Google Search Central. (2026). AI features and your website. https://developers.google.com/search/docs/appearance/ai-features Verified 30 October 2026.
- Lewandowski, D., Sünkler, S., & Yagci, N. (2021). The influence of search engine optimization on Google's results: A multi-dimensional approach for detecting SEO. WebSci 2021, 12 to 20. doi:10.1145/3447535.3462479 . Accessible author original: https://searchstudies.org/wp-content/uploads/2021/08/3447535.3462479.pdf Verified 30 October 2026.
- Broadcastwell. (2026). Do AI engines cite optimized pages? [Registered study plan]. OSF. Platform registration timestamp 30 October 2026, 01:06:12 UTC. https://doi.org/10.17605/OSF.IO/DVYFU Verified 30 October 2026.

## Report publication status

OSF preprint: not pursued.

Email research@broadcastwell.com.

## Cite this page

Broadcastwell research team. (2026, October 30). *How do you write a page an AI engine can quote?*. Broadcastwell. https://docs.broadcastwell.com/research/playbooks/pages-an-ai-engine-can-quote/ Published 30 October 2026; updated November 4, 2026.

```bibtex
@online{broadcastwell2026research25,
  author = {{Broadcastwell research team}},
  title = {How do you write a page an AI engine can quote?},
  year = {2026},
  date = {2026-10-30},
  url = {https://docs.broadcastwell.com/research/playbooks/pages-an-ai-engine-can-quote/},
  urldate = {2026-10-30},
  note = {Published 2026-10-30; updated 2026-11-04}
}
```

Prepared by the Broadcastwell research team. Lead: Vikram Patel.

Sources checked 30 October 2026. Not peer reviewed. Lead updated November 2, 2026.

Last updated: 2026-11-04. Next review: 2027-02-02.

## Continue

- [Run a free visibility check](https://audit.broadcastwell.com/).
- [Read the page-writing chapter](https://docs.broadcastwell.com/comparison-gate/).
